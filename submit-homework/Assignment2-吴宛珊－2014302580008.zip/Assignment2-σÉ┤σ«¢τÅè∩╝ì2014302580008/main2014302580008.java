import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;
public class main2014202580008 {

	public static void main(String[] args) throws IOException {
		//用jsoup直接解析url
		Document doc = (Document)Jsoup.connect
				("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing").get();
		//用属性值得到element
		Elements ListDiv = (Elements) ((Element) doc).getElementsByAttributeValue
				("class","details col-md-10 col-sm-9 col-xs-7");
		//System.out.print(ListDiv.get(0));
		//遍历element，用正则表达式提取出电话号码，邮箱
		for (Element element :ListDiv) {
			Pattern pattern_tel = Pattern.compile("[0-9]{3}\\-[0-9]+");
			Matcher matcher_tel = pattern_tel.matcher(element.text());
			Pattern pattern_eml = Pattern.compile("[a-zA-Z]+[a-zA-Z0-9\\_]*\\@([a-zA-Z]+\\.)+[a-zA-Z0-9]+");
			Matcher matcher_eml = pattern_eml.matcher(element.text());
			if (matcher_tel.find()) {
			    System.out.println("正则表达式提取电话号码:"+matcher_tel.group());
			    }
			if (matcher_eml.find()){
				System.out.println("正则表达式提取邮箱:"+ matcher_eml.group());
			}
		}
		//提取出教师姓名，简介，研究方向，邮箱及电话号码，教育研究经历，研究领域等
		Elements Detail = (Elements) ((Element) doc).getElementsByAttributeValue
				("class","details col-md-12 col-sm-12 col-xs-12");
		System.out.println(ListDiv.text());
		System.out.println(Detail.text());
		
		FileOutputStream fop = null;
		  File file;
		  String s_ListDiv = ListDiv.text();
		  String s_Detail = Detail.text();

		  try {

		   file = new File("/Users/zhaodeming/Desktop/Page.txt");
		   fop = new FileOutputStream(file);

		   
		   if (!file.exists()) {
		    file.createNewFile();
		   }

		   
		   byte[] contentInBytes = s_ListDiv.getBytes();
		   byte[] contentInBytes1 = s_Detail.getBytes();
           fop.write(contentInBytes);
		   fop.write(contentInBytes1);
		   fop.flush();
		   fop.close();
		  }
		  catch (IOException e) {
			   e.printStackTrace();
			  } finally {
			   try {
			    if (fop != null) {
			     fop.close();
			    }
			   } catch (IOException e) {
			    e.printStackTrace();
			   }
			  }
	}
		  
}	
